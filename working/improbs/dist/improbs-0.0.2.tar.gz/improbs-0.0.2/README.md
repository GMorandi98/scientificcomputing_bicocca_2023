# My trivial module

Test a trivial python package